
# Windows Service & Process Monitoring Agent

Real-time Windows defender-style agent that watches processes and services for suspicious parent-child chains, rogue startup entries, and unauthorized executables. Designed for blue-team labs, incident-response drills, or classroom demos.

## Features
- Parent-child anomaly detection (e.g., `winword.exe -> powershell.exe`).
- Startup service audit to flag new or misconfigured services.
- Whitelist/blacklist-driven unauthorized process detection, with path heuristics (Temp/AppData).
- Structured alert log plus human-readable report (JSON + TXT).
- Graceful fallbacks when WMI/pywin32 are not installed (process monitoring still works).

## Quick Start (PowerShell)
1. `python -m venv .venv`
2. `./.venv/Scripts/Activate.ps1`
3. `pip install -r requirements.txt`
4. Run a single sweep: `python -m src.monitor --once`
5. Run continuously (default 10s interval): `python -m src.monitor --interval 15`

Artifacts land in:
- `logs/detections.log` – rolling log of alerts
- `reports/` – timestamped JSON and TXT summaries per sweep

## How Detection Works
- **Parent-Child rules:** configurable pairs live in `src/config.py` under `SUSPICIOUS_PARENT_CHILD`. Any matching chain emits a high-severity alert.
- **Unauthorized processes:** anything not on the whitelist or explicitly blacklisted, running from user-writable locations (Temp/AppData) is flagged.
- **Startup services:** WMI service enumeration looks for new or odd file paths and services set to auto-start from non-system locations.

## Customizing
- Edit `src/config.py` to tweak whitelists, blacklists, and rules.
- Provide external lists via `--whitelist` / `--blacklist` (one process name per line).
- Adjust sweep cadence with `--interval` or use `--once` for a snapshot.

## Reporting
Every sweep writes two files in `reports/`:
- `report-YYYYMMDD-HHMMSS.json` – machine-friendly alerts and metadata.
- `report-YYYYMMDD-HHMMSS.txt` – concise human-readable summary.

## Limitations
- Requires Windows with PowerShell and Python 3.9+.
- Service auditing uses WMI; if `wmi`/`pywin32` are not available, the script skips that step but continues process monitoring.

## Project Structure
- `src/config.py` – detection rules and defaults
- `src/monitor.py` – main agent logic and CLI
- `src/reporting.py` – logging and report writers
- `requirements.txt` – Python dependencies

## Next Steps / Ideas
- Add signature verification (Authenticode) to reduce false positives.
- Emit Windows Event Log records for SIEM ingestion.
- Add YARA-based module scanning or ETW consumer for richer telemetry.